export const convertUnixTimeStampToDate = (unixTimeStamp) => {
  const ms = unixTimeStamp * 1;
  return new Date(ms).toLocaleDateString();
};
