import React, { useState, useEffect } from "react";

const Details = (props) => {
  // console.log(props.data.results.description);
  return (
    <div>
      <br />
      <h1>DETAILS</h1>
      <h1>name: {props.data.results.name}</h1>
      <h1>ticker: {props.data.results.ticker}</h1>
      <h1>
        shares outstanding: {props.data.results.share_class_shares_outstanding}
      </h1>
      {props.data.results.description != undefined && (
        <h1>description: {props.data.results.description}</h1>
      )}
      {props.data.results.market_cap != undefined && (
        <h1>market cap: {props.data.results.market_cap}</h1>
      )}
    </div>
  );
};

export default Details;
