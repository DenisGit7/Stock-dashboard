import React, { useState, useEffect } from "react";
import New from "./New.jsx";
const News = (props) => {
  // console.log(props);

  const items = props.data.results.map((item, index) => {
    return <New {...item} index={index} />;
  });

  return (
    <div>
      <h1>NEWS</h1>

      {items}
    </div>
  );
};

export default News;
