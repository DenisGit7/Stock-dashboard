import React from "react";
import Axios from "axios";
import { useState, useEffect } from "react";
import Symbol from "./Symbol";

const Watchlist = () => {
  const [userData, setUserData] = useState([]);
  const [watchlist, setWatchlist] = useState([]);

  //   const location = useLocation();
  //   const { id } = location.state;
  const id = "6679ae5a438962cbbede9a27";

  useEffect(() => {
    console.log("USE EFFECT");
    Axios.get(`http://localhost:3000/users/${id}`)
      .then((response) => {
        setUserData([response.data]);
      })
      .catch((error) => {
        console.log(error);
      });
    console.log(userData);
    const items = userData.map((item) => {
      return <Symbol {...item} changeList={changeList()} />;
    });
    setWatchlist(items);
  }, []);

  const changeList = () => {
    console.log("TEST");

    Axios.get(`http://localhost:3000/users/${id}`)
      .then((response) => {
        setUserData([response.data]);
      })
      .catch((error) => {
        console.log(error);
      });
    console.log(userData);
  };

  // console.log(watchlist);
  return (
    <div>
      <h1>WATCHLIST</h1>
      {watchlist}
    </div>
  );
};

export default Watchlist;
