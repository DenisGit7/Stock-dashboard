import React, { useState, useEffect } from "react";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { convertUnixTimeStampToDate } from "../helpers/date.jsx";

const Chart = (props) => {
  const formatData = (data) => {
    return data.results.map((item, index) => {
      return {
        value: parseFloat(item.c.toFixed(2)),
        date: convertUnixTimeStampToDate(item.t),
      };
    });
  };

  return (
    <div>
      <h1>CHART</h1>
      <ResponsiveContainer aspect={3}>
        <AreaChart data={formatData(props.data)}>
          <Area
            width={500}
            height={400}
            type="monotone"
            dataKey="value"
            stroke="#312e81"
            fillOpacity={1}
            strokeWidth={0.5}
          />
          <Tooltip />

          <XAxis dataKey="date" />
          <YAxis
            tickCount={10}
            domain={["auto", "auto"]}
            allowDecimals={true}
            unit="$"
            label={{ value: "Price", angle: -90, position: "insideLeft" }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default Chart;
