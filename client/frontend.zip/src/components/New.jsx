import React from "react";

const New = (props) => {
  // console.log(props);
  return (
    <div>
      New
      <h2>{props.publisher.name}</h2>
      <h2>{props.description}</h2>
      <h2>{props.article_url}</h2>
      <img src={props.image_url} width={200} />
    </div>
  );
};

export default New;
