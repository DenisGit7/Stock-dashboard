require("dotenv").config();

import { restClient } from "@polygon.io/client-js";
const rest = restClient(
  "ZJpxeHojXKi4rc3GOz5EDc0DuSBgsY2W",
  "https://api.polygon.io"
);
let NewsToReturn = "";
async function getTickerNews(symbol) {
  //   console.log(symbol);
  const response = await fetch(
    `https://api.polygon.io/v2/reference/news?ticker=${symbol}&limit=10&apiKey=ZJpxeHojXKi4rc3GOz5EDc0DuSBgsY2W`
  );
  const news = await response.json();
  // console.log(news);

  return news;
}

export default getTickerNews;

// await rest.reference
// .tickerNews(symbol)
// .then((data) => {
//   //   console.log(data);
//   NewsToReturn = data;
// })
// .catch((e) => {
//   console.error("An error happened:", e);
// });
// console.log(detailsToReturn.results);
