require("dotenv").config();

import { restClient } from "@polygon.io/client-js";
const rest = restClient(
  "ZJpxeHojXKi4rc3GOz5EDc0DuSBgsY2W",
  "https://api.polygon.io"
);
let detailsToReturn = "";
async function getStockDetails(symbol) {
  //   console.log(symbol);
  await rest.reference
    .tickerDetails(symbol)
    .then((data) => {
      //   console.log(data.results.ticker);
      detailsToReturn = data;
    })
    .catch((e) => {
      console.error("An error happened:", e);
    });
  //   console.log(detailsToReturn.results);
  return detailsToReturn;
}

export default getStockDetails;
