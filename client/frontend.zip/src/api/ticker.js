require("dotenv").config();

import { restClient } from "@polygon.io/client-js";
const rest = restClient(
  "ZJpxeHojXKi4rc3GOz5EDc0DuSBgsY2W",
  "https://api.polygon.io"
);
let dataToReturn = "";

async function getStockPrice(symbol) {
  await rest.stocks
    .aggregates(symbol, 1, "day", "2022-06-10", "2024-06-14")
    .then((data) => {
      dataToReturn = data;
    })
    .catch((e) => {
      console.error("An error happened:", e);
    });
  return dataToReturn;
}

export default getStockPrice;
