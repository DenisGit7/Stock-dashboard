import React from "react";

const Cookies = () => {
  return <div>Cookies</div>;
};

export default Cookies;
