import React, { useState, useEffect } from "react";
import { useCookies } from "react-cookie";
import Cookies from "./Cookies";
import { useNavigate } from "react-router-dom";

const navigate = useNavigate();

function Local() {
  const navigate = useNavigate();
  const [cookies, setCookie, removeCookie] = useCookies(["user"]);

  const [list, setList] = useState([]);
  const [temp, setTemp] = useState([]);
  const [values, setValues] = useState(() => {
    const saved = localStorage.getItem("list");
    return saved != null ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem("list", JSON.stringify(values));
  }, [values]);

  const handleChange = (e) => {
    setTemp(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(temp);

    setValues([...values, temp]);

    console.log(values);
    const items = values.map((item) => {
      return <li>{item}</li>;
    });
    setList(items);
  };

  const handleSetCookie = (e) => {
    setCookie("user", e.target.value, { path: "/" });
    navigate("/cookies");
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="To Do"
          onChange={handleChange}
          name="task"
        />
        <button>Submit</button>
        {list}
      </form>

      <br />
      <br />
      <br />
      <input type="text" placeholder="Username" name="user" />
      <button>Submit onClick={() => handleSetCookie(e)}</button>
    </>
  );
}

export default Local;
