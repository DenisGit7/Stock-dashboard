import React from "react";
import { useState, useEffect } from "react";
import Details from "../components/Details.jsx";
import Chart from "../components/Chart.jsx";
import getStockPrice from "../api/ticker.js";
import getStockDetails from "../api/tickerDetails.js";
import News from "../components/News.jsx";
import getTickerNews from "../api/tickerNews.js";
import Watchlist from "../components/Watchlist.jsx";

const Home = () => {
  const [dataToChart, setDataToChart] = useState();
  const [dataToDetails, setDataToDetails] = useState();
  const [dataToNews, setDataToNews] = useState();
  const [loading, setLoading] = useState(false);
  const [searchValue, setSearchValue] = useState();

  useEffect(() => {
    const updateInital = async (stock) => {
      let chartFromApi = await getStockPrice(stock);
      let detailsFromApi = await getStockDetails(stock);
      let newsFromApi = await getTickerNews(stock);
      setDataToNews(newsFromApi);
      setDataToChart(chartFromApi);
      setDataToDetails(detailsFromApi);
      setLoading(true);
    };
    updateInital("NVDA");
  }, []);
  // console.log(loading);
  const updateData = async (stock) => {
    let chartFromApi = await getStockPrice(stock);
    let detailsFromApi = await getStockDetails(stock);
    let newsFromApi = await getTickerNews(stock);
    setDataToNews(newsFromApi);
    setDataToDetails(detailsFromApi);
    setDataToChart(chartFromApi);
  };
  return (
    <div>
      <div class="parent">
        <div class="div1">
          {" "}
          <h1>Home</h1>
        </div>
        <div class="div2">
          <div>
            <input
              type="text"
              name="symbol"
              onChange={(e) => {
                setSearchValue(e.target.value.toUpperCase());
              }}
              onKeyPress={(e) => {
                if (e.key === "Enter") {
                  updateData(searchValue);
                }
              }}
            />
            <button onClick={() => updateData(searchValue)}>Search</button>
          </div>{" "}
        </div>
        <div class="div3">{loading && <Chart data={dataToChart} />}</div>
        <div class="div4">{loading && <Details data={dataToDetails} />} </div>
        <div class="div5"> {loading && <Watchlist />} </div>
        <div class="div6"> {loading && <News data={dataToNews} />}</div>
      </div>
    </div>
  );
};

export default Home;
