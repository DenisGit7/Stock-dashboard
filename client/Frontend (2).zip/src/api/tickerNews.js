require("dotenv").config();

async function getTickerNews(symbol) {
  const response = await fetch(
    `https://api.polygon.io/v2/reference/news?ticker=${symbol}&limit=5&apiKey=ZJpxeHojXKi4rc3GOz5EDc0DuSBgsY2W`
  );
  const news = await response.json();

  return news;
}

export default getTickerNews;
