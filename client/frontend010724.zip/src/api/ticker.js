require("dotenv").config();

import { restClient } from "@polygon.io/client-js";
const rest = restClient(
  "ZJpxeHojXKi4rc3GOz5EDc0DuSBgsY2W",
  "https://api.polygon.io"
);
let dataToReturn = "";

async function getStockPrice(symbol, interval = "day", pastDate, currentDate) {
  console.log(interval);
  console.log(pastDate);
  await rest.stocks
    .aggregates(symbol, 1, interval, pastDate, currentDate)
    .then((data) => {
      if (data.resultsCount != 0) {
        dataToReturn = data;
      } else {
        dataToReturn = "error";
      }
    })
    .catch((e) => {
      console.error("An error happened:", e);
    });
  console.log(dataToReturn);
  return dataToReturn;
}

export default getStockPrice;
